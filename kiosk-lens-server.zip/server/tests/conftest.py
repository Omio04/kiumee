import copy, json, pathlib
import pytest

ROOT = pathlib.Path(__file__).resolve().parent.parent


@pytest.fixture(scope="session")
def snaps():
    return {p.stem: json.loads(p.read_text(encoding="utf-8")) for p in (ROOT / "testdata/snapshots").glob("*.json")}


def make_req(snaps, screen, utterance="", history=None):
    return {"utterance": utterance, "snapshot": copy.deepcopy(snaps[screen]), "history": history or []}
