"""계약 테스트: 같은 시나리오를 FakeGuideAgent와 LlmGuideAgent(가짜 LLM) 양쪽에 돌려 응답 규약을 확인."""
import pytest
from app.agent import FakeGuideAgent, LlmGuideAgent
from app.llm import HeuristicFakeLlmClient, ScriptedFakeLlmClient, LlmTimeout
from app.models import GuideRequest, GuideAction
from app.settings import Settings
from tests.conftest import make_req

S = Settings(app_key="k", llm_provider="fake")
S_NOFAST = Settings(app_key="k", llm_provider="fake", fastpath=False)


def agents():
    return {"fake": FakeGuideAgent(), "llm": LlmGuideAgent(HeuristicFakeLlmClient(), S)}


@pytest.mark.parametrize("name", ["fake", "llm"])
@pytest.mark.parametrize("screen,goal", [("s01_dine", "포장해 주세요"), ("s02_menu", "아메리카노 주세요"),
                                          ("s03_options", "따뜻한 걸로요"), ("s04_cart", "결제"), ("s05_payment", "카드로요")])
async def test_contract_guide(snaps, name, screen, goal):
    r = (await agents()[name].next(GuideRequest.model_validate(make_req(snaps, screen, goal)))).response
    assert r.action == GuideAction.GUIDE
    ids = {e["id"]: e for e in snaps[screen]["elements"]}
    assert r.targetId in ids and ids[r.targetId]["kind"] == "BUTTON_LIKE" and r.guideText == ids[r.targetId]["text"]


@pytest.mark.parametrize("name", ["fake", "llm"])
async def test_contract_done_on_card_screen(snaps, name):
    r = (await agents()[name].next(GuideRequest.model_validate(make_req(snaps, "s06_card", "")))).response
    assert r.action == GuideAction.DONE and r.message and r.targetId is None


@pytest.mark.parametrize("name", ["fake", "llm"])
async def test_contract_no_buttons_unknown(name):
    snap = {"screenId": "x", "elements": []}
    r = (await agents()[name].next(GuideRequest.model_validate({"utterance": "뭐", "snapshot": snap}))).response
    assert r.action == GuideAction.UNKNOWN and r.message


async def test_llm_unknown_button_rejected(snaps):
    llm = ScriptedFakeLlmClient(['{"action":"GUIDE","targetId":"ghost","guideText":"유령","message":null}'])
    a = LlmGuideAgent(llm, S_NOFAST)
    res = await a.next(GuideRequest.model_validate(make_req(snaps, "s02_menu", "뭔가 주세요")))
    assert res.response.action == GuideAction.UNKNOWN and res.meta["rejected"] and len(llm.calls) == 1


async def test_llm_bad_format_retried_once_then_ok(snaps):
    llm = ScriptedFakeLlmClient(["죄송합니다", '{"action":"GUIDE","targetId":"e3","guideText":"x"}'])
    res = await LlmGuideAgent(llm, S_NOFAST).next(GuideRequest.model_validate(make_req(snaps, "s01_dine", "포장")))
    assert res.response.targetId == "e3" and len(llm.calls) == 2 and res.meta["retry"]
    assert "형식이 틀렸" in llm.calls[1]["user"]


async def test_llm_bad_format_twice_unknown_no_third_call(snaps):
    llm = ScriptedFakeLlmClient(["엉뚱", "또 엉뚱"])
    res = await LlmGuideAgent(llm, S_NOFAST).next(GuideRequest.model_validate(make_req(snaps, "s01_dine", "포장")))
    assert res.response.action == GuideAction.UNKNOWN and len(llm.calls) == 2


async def test_fastpath_skips_llm(snaps):
    llm = ScriptedFakeLlmClient(["X"])
    res = await LlmGuideAgent(llm, S).next(GuideRequest.model_validate(make_req(snaps, "s02_menu", "아메리카노 주세요")))
    assert res.response.source == "fastpath" and llm.calls == []


async def test_fastpath_off_calls_llm(snaps):
    llm = ScriptedFakeLlmClient(['{"action":"GUIDE","targetId":"e4","guideText":"아메리카노"}'])
    res = await LlmGuideAgent(llm, S_NOFAST).next(GuideRequest.model_validate(make_req(snaps, "s02_menu", "아메리카노 주세요")))
    assert res.response.source == "llm" and len(llm.calls) == 1


async def test_timeout_propagates(snaps):
    a = LlmGuideAgent(ScriptedFakeLlmClient([LlmTimeout("t")]), S_NOFAST)
    with pytest.raises(LlmTimeout):
        await a.next(GuideRequest.model_validate(make_req(snaps, "s01_dine", "포장")))


async def test_prompt_has_only_k_candidates_and_no_card_digits(snaps):
    llm = ScriptedFakeLlmClient(['{"action":"UNKNOWN","message":"모르겠어요"}'])
    s = Settings(app_key="k", llm_provider="fake", fastpath=False, candidate_k=3)
    await LlmGuideAgent(llm, s).next(GuideRequest.model_validate(make_req(snaps, "s02_menu", "카드번호 1234567812345678 뭐")))
    user = llm.calls[0]["user"]
    assert user.split("[후보]")[1].strip().count("\n") + 1 == 3 and "12345678" not in user


async def test_history_goal_used_when_utterance_empty(snaps):
    h = [{"role": "USER", "text": "아이스 주세요"}, {"role": "GUIDE", "text": "아메리카노", "targetId": "e4"}]
    res = await LlmGuideAgent(HeuristicFakeLlmClient(), S).next(
        GuideRequest.model_validate(make_req(snaps, "s03_options", "", h)))
    assert res.response.guideText == "ICE"
