# AI 키오스크 렌즈 · P4 에이전트 서버 (v0.1)

`POST /v1/guide/next` — OCR 글자·좌표와 어르신 발화를 받아 "다음에 누를 버튼 하나"를 돌려줍니다. **이미지는 받지 않습니다**(필드가 있으면 400).

## 실행
```
pip install -r requirements-dev.txt
KL_SKIP_APP_INIT=1 pytest -q                       # 테스트 60개 (키·네트워크 불필요)
APP_KEY=dev LLM_PROVIDER=fake uvicorn app.main:app --port 8080     # 키 없이 연동 연습 (Android가 바로 붙일 수 있음)
APP_KEY=... ANTHROPIC_API_KEY=... uvicorn app.main:app             # 실제 LLM
docker build -t kl-agent . && docker run -p 8080:8080 -e APP_KEY=... -e ANTHROPIC_API_KEY=... kl-agent
```
클라우드 1곳(Cloud Run/Fly/Render 등 컨테이너 가능한 곳)에는 이 Docker 이미지를 올리고 환경변수 `APP_KEY`, `ANTHROPIC_API_KEY`만 설정하면 됩니다. `PORT` 환경변수를 따릅니다.

## API
요청 헤더 `X-App-Key`, 본문(JSON):
```json
{"utterance":"아메리카노 주세요","sessionId":"opt",
 "snapshot":{"screenId":"s02","elements":[{"id":"e4","text":"아메리카노","kind":"BUTTON_LIKE","confidence":0.95,
   "rect":{"left":0.05,"top":0.25,"right":0.3,"bottom":0.4}}]},
 "history":[{"role":"USER|GUIDE","text":"...","targetId":"e4"}]}
```
응답 200: `{"action":"GUIDE|ASK_USER|DONE|UNKNOWN","targetId","guideText","message","source"}`
- GUIDE: `targetId`+`guideText`(실제 버튼 글자) / 그 외: `message`(어르신께 할 말)
- 후보 밖 targetId는 절대 나가지 않음(→UNKNOWN). `utterance`가 비면 history의 마지막 USER 발화를 목표로 사용.

오류 `{"error":{"code","message","requestId"}}`: 400 invalid_request · 401 unauthorized · 429 rate_limited(+Retry-After) · 502 llm_error · 504 llm_timeout · 500 internal. 400은 입력 값을 되돌려주지 않음.

## 처리 순서
개인정보 마스킹(카드·주민번호) → 로컬 규칙(결제 진행 문구면 LLM 없이 DONE) → 자모 n-gram 후보 K=8 → 빠른 길(거의 일치+격차 크면 LLM 생략) → LLM(4초, JSON) → 형식 오류 시 1회만 재요청 → 화이트리스트 검증.

## 평가
```
python scripts/make_fixtures.py                 # 손으로 쓴 화면 6개 + 케이스 18개 재생성
python scripts/evaluate.py --llm heuristic      # 전체 흐름 점검 (가짜 LLM)
ANTHROPIC_API_KEY=... python scripts/evaluate.py --llm anthropic --repeat 3 --fail-under 0.85
```
**주의**: fake/heuristic 결과(현재 100%)는 파이프라인 점검용이며, 케이스를 보고 동의어를 넣었기 때문에 실제 정확도가 아닙니다. 85%·p95 2초 목표는 실제 키 + **실제 키오스크 OCR 스냅샷**(같은 JSON 형식으로 `testdata/snapshots`에 추가)으로 재야 합니다. 로컬 측정: HTTP 포함 p95 약 1.3ms(가짜 LLM, 서버 자체 비용만).

## 가정 (1일차 12:00 :core-model 회의에서 맞출 것)
설계서 본문을 못 봐서 계획서에서 추정했습니다. 이름만 `app/models.py`에서 고치면 됩니다.
| 항목 | 가정 |
|---|---|
| 요소 | id, text, kind(BUTTON_LIKE/PRICE/TEXT), rect(정규화 left/top/right/bottom), confidence |
| 요청 | utterance, snapshot{screenId, elements≤300}, history≤20(서버는 마지막 5개), sessionId |
| 응답 | action 4종, targetId, guideText, message, source |
| 인증 | `X-App-Key` 고정 키, 서버 키가 비면 전부 401 |
| 모델 | 기본 `claude-haiku-5-5` (실측 후 `LLM_MODEL`로 교체) |
| 결제 범위 | 결제 수단 선택까지 안내, 카드 투입 문구 등이 보이면 DONE |

## 미검증
실제 Anthropic 호출, Docker 이미지 빌드(이 환경에 데몬 없음), 실제 OCR 입력, 실제 p95는 **아직 해보지 않았습니다**. Anthropic 호출부는 모의 HTTP(MockTransport)로 상태코드·타임아웃 매핑만 확인했습니다.
