"""ActionValidator: LLM이 한 말을 그대로 믿지 않습니다.

- 후보 밖 targetId → UNKNOWN (설계: 화이트리스트). 화면에 없는 버튼을 안내하는 일을 막습니다.
- guideText는 항상 실제 버튼 글자로 되돌립니다 (LLM이 글자를 바꿔 말해도 화면과 일치).
- 메시지가 없거나 너무 길면 기본 문구로 바꿉니다.
"""
from __future__ import annotations

from typing import Dict

from .models import GuideAction, GuideResponse, LlmAction, ScreenElement

MSG_UNKNOWN = "버튼을 찾지 못했어요. 화면이 잘 보이게 정면에서 비춰주세요."
MSG_ASK = "무엇을 드시고 싶으세요?"
MSG_DONE = "결제 수단을 고르셨어요. 직원 또는 화면 안내를 따라주세요."
MAX_MESSAGE = 60


def _clean_message(m: str | None, default: str) -> str:
    m = (m or "").strip()
    if not m or len(m) > MAX_MESSAGE:
        return default
    return m


class ActionValidator:
    def validate(self, a: LlmAction, candidates: Dict[str, ScreenElement], source: str = "llm") -> GuideResponse:
        if a.action == GuideAction.GUIDE:
            el = candidates.get(a.targetId or "")
            if el is None:
                return GuideResponse(action=GuideAction.UNKNOWN, message=MSG_UNKNOWN, source="fallback")
            return GuideResponse(action=GuideAction.GUIDE, targetId=el.id, guideText=el.text, source=source)
        if a.action == GuideAction.ASK_USER:
            return GuideResponse(action=GuideAction.ASK_USER, message=_clean_message(a.message, MSG_ASK), source=source)
        if a.action == GuideAction.DONE:
            return GuideResponse(action=GuideAction.DONE, message=_clean_message(a.message, MSG_DONE), source=source)
        return GuideResponse(action=GuideAction.UNKNOWN, message=_clean_message(a.message, MSG_UNKNOWN), source=source)
