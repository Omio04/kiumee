"""GuideAgent: 요청 하나를 받아 다음 행동(GuideResponse)을 돌려줍니다.

처리 순서 (LlmGuideAgent)
  1. 개인정보 정리            privacy.sanitize
  2. 로컬 규칙                "카드를 넣어 주세요" 같은 결제 진행 화면이면 LLM 없이 DONE
  3. 후보 축소                JamoNgramRanker (K=8)
  4. 빠른 길(선택)            글자가 거의 똑같고 1등이 뚜렷하면 LLM 없이 GUIDE
  5. LLM 판단                 JSON 강제 · 형식이 틀리면 1회만 다시 요청
  6. 검증                     후보 밖 targetId → UNKNOWN
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Protocol

from . import privacy
from .jamo import normalize
from .llm import LlmClient
from .models import ElementKind, GuideAction, GuideRequest, GuideResponse, HistoryRole, ScreenElement
from .parser import ActionParser, ParseError
from .prompt import RETRY_NOTE, SYSTEM, build_user
from .ranker import JamoNgramRanker
from .settings import Settings
from .validator import MSG_ASK, MSG_DONE, MSG_UNKNOWN, ActionValidator

# 결제가 "진행 중"이라는 뜻의 화면 문구. 이 계획의 범위는 결제 수단 선택까지라서, 보이면 안내를 마칩니다.
_DONE_PATTERNS = [normalize(p) for p in (
    "카드를 넣", "카드를 투입", "카드 투입", "투입구", "카드를 삽입", "카드를 태그", "결제 진행", "결제 중", "승인 중",
    "결제가 완료", "결제 완료", "주문이 완료", "주문 완료", "주문번호",
)]


@dataclass
class GuideResult:
    response: GuideResponse
    meta: Dict[str, object] = field(default_factory=dict)    # 내용이 아닌 진단 값만 (개수·시간·경로)


class GuideAgent(Protocol):
    async def next(self, req: GuideRequest) -> GuideResult: ...


def _goal_of(req: GuideRequest) -> str:
    """이번 발화가 비어 있으면(화면만 바뀐 경우) 마지막 사용자 발화를 목표로 씁니다."""
    if req.utterance.strip():
        return req.utterance.strip()
    for h in reversed(req.history):
        if h.role == HistoryRole.USER and h.text.strip():
            return h.text.strip()
    return ""


def _is_done_screen(elements: List[ScreenElement]) -> bool:
    for e in elements:
        t = normalize(e.text)
        if any(p in t for p in _DONE_PATTERNS):
            return True
    return False


class LlmGuideAgent:
    def __init__(self, llm: LlmClient, settings: Settings):
        self.llm = llm
        self.s = settings
        self.ranker = JamoNgramRanker(settings.candidate_k)
        self.parser = ActionParser()
        self.validator = ActionValidator()

    async def next(self, req: GuideRequest) -> GuideResult:
        t0 = time.perf_counter()
        meta: Dict[str, object] = {"llm_calls": 0, "retry": False, "rejected": False}

        req, dropped = privacy.sanitize(req)
        meta["dropped"] = dropped
        els = req.snapshot.elements

        # 2) 로컬 규칙: 결제 진행 화면
        if _is_done_screen(els):
            meta.update(source="rule", candidates=0)
            return self._finish(GuideResponse(action=GuideAction.DONE, message=MSG_DONE, source="rule"), meta, t0)

        goal = _goal_of(req)
        ranked = self.ranker.rank(els, goal)
        meta["candidates"] = len(ranked)
        if not ranked:
            meta["source"] = "fallback"
            return self._finish(GuideResponse(action=GuideAction.UNKNOWN, message=MSG_UNKNOWN, source="fallback"), meta, t0)

        # 4) 빠른 길
        if self.s.fastpath and goal:
            top = ranked[0]
            second = ranked[1].match if len(ranked) > 1 else 0.0
            if top.match >= self.s.fast_min_score and top.match - second >= self.s.fast_margin:
                meta["source"] = "fastpath"
                return self._finish(GuideResponse(action=GuideAction.GUIDE, targetId=top.element.id,
                                                  guideText=top.element.text, source="fastpath"), meta, t0)

        # 5) LLM
        candidates = [r.element for r in ranked]
        by_id = {c.id: c for c in candidates}
        context = [e.text for e in els if e.kind == ElementKind.TEXT][:6]
        user = build_user(goal, req.history, candidates, context)

        action = None
        for attempt in range(2):                       # 최초 1회 + 형식 오류 시 1회
            raw = await self.llm.complete(SYSTEM, user if attempt == 0 else user + RETRY_NOTE, self.s.llm_timeout_s)
            meta["llm_calls"] = int(meta["llm_calls"]) + 1
            try:
                action = self.parser.parse(raw)
                break
            except ParseError:
                meta["retry"] = True
        if action is None:
            meta["source"] = "fallback"
            return self._finish(GuideResponse(action=GuideAction.UNKNOWN, message=MSG_UNKNOWN, source="fallback"), meta, t0)

        # 6) 검증
        resp = self.validator.validate(action, by_id)
        if action.action == GuideAction.GUIDE and resp.action == GuideAction.UNKNOWN:
            meta["rejected"] = True                    # LLM이 후보에 없는 버튼을 말함
        meta["source"] = resp.source
        return self._finish(resp, meta, t0)

    @staticmethod
    def _finish(resp: GuideResponse, meta: Dict[str, object], t0: float) -> GuideResult:
        meta["total_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        return GuideResult(resp, meta)


class FakeGuideAgent:
    """LLM 없이 항상 같은 규칙으로 답하는 가짜 에이전트. Android 쪽 개발과 계약 테스트에 씁니다.
    규칙: 후보 없음→UNKNOWN / 목표 없음→ASK_USER / 그 외 1등 후보→GUIDE."""

    def __init__(self, k: int = 8):
        self.ranker = JamoNgramRanker(k)

    async def next(self, req: GuideRequest) -> GuideResult:
        req, dropped = privacy.sanitize(req)
        goal = _goal_of(req)
        ranked = self.ranker.rank(req.snapshot.elements, goal)
        if _is_done_screen(req.snapshot.elements):
            r = GuideResponse(action=GuideAction.DONE, message=MSG_DONE, source="fake")
        elif not ranked:
            r = GuideResponse(action=GuideAction.UNKNOWN, message=MSG_UNKNOWN, source="fake")
        elif not goal:
            r = GuideResponse(action=GuideAction.ASK_USER, message=MSG_ASK, source="fake")
        else:
            e = ranked[0].element
            r = GuideResponse(action=GuideAction.GUIDE, targetId=e.id, guideText=e.text, source="fake")
        return GuideResult(r, {"source": "fake", "candidates": len(ranked), "dropped": dropped, "llm_calls": 0,
                               "retry": False, "rejected": False, "total_ms": 0.0})
