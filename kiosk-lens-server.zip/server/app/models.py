"""API 계약(요청·응답 모델).

주의: 설계서 v0.1의 :core-model 정의를 아직 못 봐서, 5일 계획서에서 추정한 형태입니다.
1일차 12:00 :core-model 확정 회의에서 이 파일의 필드 이름만 맞추면 나머지 코드는 그대로 쓸 수 있습니다.
(추정한 부분은 README의 "가정" 표에 정리했습니다.)
"""
from __future__ import annotations

from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

MAX_ELEMENTS = 300
MAX_HISTORY = 5          # 설계: 이력 최대 5개


class NormRect(BaseModel):
    """회전 보정된 분석 프레임 기준 정규화 좌표 (0.0~1.0)."""
    left: float = Field(ge=0.0, le=1.0)
    top: float = Field(ge=0.0, le=1.0)
    right: float = Field(ge=0.0, le=1.0)
    bottom: float = Field(ge=0.0, le=1.0)

    @model_validator(mode="after")
    def _ordered(self) -> "NormRect":
        if self.right <= self.left or self.bottom <= self.top:
            raise ValueError("rect must have positive area")
        return self


class ElementKind(str, Enum):
    BUTTON_LIKE = "BUTTON_LIKE"    # 누를 수 있어 보이는 글자 (후보가 될 수 있음)
    PRICE = "PRICE"                # 가격 글자 (후보 제외)
    TEXT = "TEXT"                  # 그 밖의 글자 (화면 문구로만 사용)


class ScreenElement(BaseModel):
    id: str = Field(min_length=1, max_length=64)       # 요소 ID (4.3장, 클라이언트가 부여한 값을 그대로 돌려줌)
    text: str = Field(min_length=1, max_length=80)
    kind: ElementKind
    rect: NormRect
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)


class ScreenSnapshot(BaseModel):
    screenId: str = Field(min_length=1, max_length=64)
    elements: List[ScreenElement] = Field(max_length=MAX_ELEMENTS)

    @field_validator("elements")
    @classmethod
    def _unique_ids(cls, v: List[ScreenElement]) -> List[ScreenElement]:
        ids = [e.id for e in v]
        if len(ids) != len(set(ids)):
            raise ValueError("element ids must be unique")
        return v


class HistoryRole(str, Enum):
    USER = "USER"
    GUIDE = "GUIDE"


class HistoryItem(BaseModel):
    role: HistoryRole
    text: str = Field(max_length=200)
    targetId: Optional[str] = Field(default=None, max_length=64)


class GuideRequest(BaseModel):
    """POST /v1/guide/next 요청. 이미지는 받지 않습니다 (설계서 2.2)."""
    utterance: str = Field(default="", max_length=200)    # STT Final 텍스트. 비어 있을 수 있음(화면만 바뀐 경우)
    snapshot: ScreenSnapshot
    history: List[HistoryItem] = Field(default_factory=list, max_length=20)   # 서버가 마지막 5개만 사용
    sessionId: Optional[str] = Field(default=None, max_length=64)

    model_config = {"extra": "forbid"}   # 모르는 필드(예: image)가 오면 400 — 실수로 이미지가 섞여 들어오는 것을 막음


class GuideAction(str, Enum):
    GUIDE = "GUIDE"          # targetId 하이라이트 + "{위치} 깜빡이는 {guideText}를 누르세요"
    ASK_USER = "ASK_USER"    # 무엇을 원하는지 되묻기 → LISTENING
    DONE = "DONE"            # 안내 종료
    UNKNOWN = "UNKNOWN"      # 버튼을 못 찾음 → 클라이언트가 "화면을 정면으로" 등 안내


class GuideResponse(BaseModel):
    action: GuideAction
    targetId: Optional[str] = None
    guideText: Optional[str] = None     # GUIDE일 때 눌러야 할 버튼의 글자
    message: Optional[str] = None       # ASK_USER · DONE · UNKNOWN일 때 어르신께 할 말
    source: str = "llm"                 # llm | fastpath | rule | fake | fallback (진단용, 내용 아님)

    @model_validator(mode="after")
    def _invariants(self) -> "GuideResponse":
        if self.action == GuideAction.GUIDE:
            if not self.targetId or not self.guideText:
                raise ValueError("GUIDE needs targetId and guideText")
        else:
            if not self.message:
                raise ValueError(f"{self.action.value} needs message")
            if self.targetId is not None:
                raise ValueError(f"{self.action.value} must not carry targetId")
        return self


class LlmAction(BaseModel):
    """LLM이 돌려주는 JSON (검증 전)."""
    action: GuideAction
    targetId: Optional[str] = None
    guideText: Optional[str] = None
    message: Optional[str] = None

    @field_validator("targetId", "guideText", "message", mode="before")
    @classmethod
    def _null_like(cls, v):
        if isinstance(v, str) and v.strip().lower() in ("", "null", "none"):
            return None
        return v
